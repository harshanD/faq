<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('js')); ?>/jquery.min.js" ></script>
    <script src="<?php echo e(asset('js')); ?>/bootstrap.min.js" ></script>

<script src="<?php echo e(asset('js')); ?>/bootstrap3-wysihtml5.all.min.js" ></script>
<script>
    $(function () {
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
        //bootstrap WYSIHTML5 - text editor
        $('.textarea').wysihtml5()
    })
</script>
</body>
</html>
<?php $__env->stopSection(); ?>



<?php /**PATH /home/harshan/Documents/xampp/htdocs/services/faq/resources/views/content/footer.blade.php ENDPATH**/ ?>