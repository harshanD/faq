<html>
<head>
    <title>Faq title</title>
    <link rel="stylesheet" href="<?php echo e(asset('css')); ?>/bootstrap.min.css" >
    <link rel="stylesheet" href="<?php echo e(asset('css')); ?>/bootstrap3-wysihtml5.min.css" >
</head>


<body>
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>


<?php echo $__env->yieldContent('footer'); ?>

<?php /**PATH /home/harshan/Documents/xampp/htdocs/services/faq/resources/views/content/header.blade.php ENDPATH**/ ?>