<html>
<head>
    <title>Faq title</title>
    <link rel="stylesheet" href="{{asset('css')}}/bootstrap.min.css" >
    <link rel="stylesheet" href="{{asset('css')}}/bootstrap3-wysihtml5.min.css" >
</head>


<body>
<div class="container">
    @yield('content')
</div>


@yield('footer')

