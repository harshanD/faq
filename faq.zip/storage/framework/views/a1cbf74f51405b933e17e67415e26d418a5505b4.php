<?php $__env->startSection('content'); ?>
    <br>
    <br>
    <div class="float-right">
        <a href="/addNew" class="btn btn-info pull-right" role="button"><span
                    class="glyphicon glyphicon-plus-sign"></span> Add New</a>
    </div>

    <br>
    <br>
    <br>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissable custom-success-box" style="margin: 15px;">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>   <?php echo e(session()->get('message')); ?> </strong>
        </div>
    <?php endif; ?>
    <br>
    <div class="panel-group" id="accordion">
        <?php $__currentLoopData = $questionWithAnswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$quesAnswer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion"
                           href="#collapse<?php echo e($id); ?>"><?php echo e($quesAnswer->question); ?></a>
                        <div class="pull-right">
                            <a href="/delete/<?php echo e($quesAnswer->id); ?>"><span style="color:red" class="glyphicon glyphicon-remove"></span>  Delete</a>
                               <a href="/edit/<?php echo e($quesAnswer->id); ?>"><span
                                        style="color:green"  class="glyphicon glyphicon-edit"></span>  Edit</a>
                        </div>

                    </h4>

                </div>

                <div id="collapse<?php echo e($id); ?>" class="panel-collapse collapse out">
                    <div class="panel-body">

                        <?php $__currentLoopData = $quesAnswer->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?= $answer->answer?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('content.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('content.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harshan/Documents/xampp/htdocs/services/faq/resources/views/faq/list.blade.php ENDPATH**/ ?>